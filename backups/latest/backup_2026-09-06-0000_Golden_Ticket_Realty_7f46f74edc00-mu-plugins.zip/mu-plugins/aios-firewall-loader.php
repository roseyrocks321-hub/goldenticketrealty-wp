<?php
// Begin AIOWPSEC Firewall
if (file_exists('/home/goldfvju/public_html/aios-bootstrap.php')) {
	include_once('/home/goldfvju/public_html/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
